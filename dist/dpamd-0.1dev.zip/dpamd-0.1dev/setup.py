from distutils.core import setup

setup(
    name='dpamd',
    version='0.1dev',
	author='MBS',
	author_email='broes.michael@gmail.com',
    packages=['dpamdapi'],
    license='Copyright DPAM',
    long_description=open('README.md').read(),
)