# __init__.py

name = "dpamd"