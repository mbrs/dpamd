# DPAM data toolkit

This directory contains an interface for interacting with DPAM SSOT API services using the Python programming language. This package is the source installer.

You are encouraged to install using 'pip' directly. 

pip install -i https://test.pypi.org/simple/ dpamd <br>
https://github.com/mbrs/dpamd/zipball/master (zip)

This version is written for Python 2.7 only.

More documentation can be found (intranet) on http://172.20.17.46/wiki/

## Getting Started

## Prerequisites
Python 2.7
libs used: Pandas, Request
## Installing

## Deployment

## License
DPAM data toolkit is copyright Degroof Petercam Asset Management.


